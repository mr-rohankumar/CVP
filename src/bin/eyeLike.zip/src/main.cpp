// Modified by Rohan Kumar

#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include <iostream>
#include <queue>

#include "findEyeCenter.h"

void find_eyes(cv::Mat &frame, cv::Rect &left_region, cv::Rect &right_region, bool debug);

int main(int argc, const char **argv) {
    if (argc != 10 && argc != 11) {
        printf("Usage: eyeLike image_path left_x left_y left_width left_height right_x right_y right_width right_height [-debug]\n");
        return -1;
    }

    cv::Mat frame = cv::imread(argv[1], cv::IMREAD_GRAYSCALE);

    if (frame.empty()) {
        printf("Error: Failed to loading image.\n");
        return -1;
    }

    cv::Rect left_region(atoi(argv[2]), atoi(argv[3]), atoi(argv[4]), atoi(argv[5]));
    cv::Rect right_region(atoi(argv[6]), atoi(argv[7]), atoi(argv[8]), atoi(argv[9]));

    find_eyes(frame, left_region, right_region, argc == 11 && !std::strcmp(argv[10], "-debug"));

    return 0;
}

void find_eyes(cv::Mat &frame, cv::Rect &left_region, cv::Rect &right_region, bool debug) {
    cv::Point left_eye = findEyeCenter(frame, left_region);
    cv::Point right_eye = findEyeCenter(frame, right_region);

    left_eye.x += left_region.x;
    left_eye.y += left_region.y;
    right_eye.x += right_region.x;
    right_eye.y += right_region.y;

    std::cout << left_eye.x << "," << left_eye.y << "," << right_eye.x << "," << right_eye.y;

    if (debug) {
        rectangle(frame, left_region, 255);
        rectangle(frame, right_region, 255);
        circle(frame, left_eye, 3, 255);
        circle(frame, right_eye, 3, 255);

        cv::namedWindow("debug");
        imshow("debug", frame);
        cv::waitKey(0);
    }
}
